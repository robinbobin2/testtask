// Модель для списка фильмов на главной
export class Movie {
  Title: string;
  Poster: string;
  Type: string;
  Year: string;
  imdbID: string;
}

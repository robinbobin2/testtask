// Модель для страницы фильма
export class MovieDetails {
  Title: string;
  Poster: string;
  Type: string;
  Year: string;
  imdbID: string;
  Actors: string;
  Director: string;
  Plot: string;
  Released: string;
  Runtime: string;
}
